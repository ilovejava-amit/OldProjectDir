/**
 * Created by yuiff on 2016/12/22.
 */
var table =
    {
        "data": {
            "languages": [{"id": 3, "name": "DAN"}, {"id": 4, "name": "DEU"}, {"id": 5, "name": "ETI"}],
            "lines": [
                {
                    "items": [
                        {"translations": []},
                        {
                            "translations": [{
                                "priority": 1,
                                "projectInfoId": 16,
                                "translateStringInfoId": 1,
                                "translateString": "设置！"
                            }]
                        },
                        {"translations": []}
                    ],
                    "engStringInfoId": 1,
                    "engString": "setting"
                }
            ],
            "projectInfoName": {"16": "MT51\/Source\/AU\/TCL"}
        }, "msg": "success"
    }